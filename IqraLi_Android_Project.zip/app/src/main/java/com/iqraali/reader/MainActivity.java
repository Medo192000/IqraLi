package com.iqraali.reader;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.speech.tts.TextToSpeech;
import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.*;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_PDF = 10, PICK_IMAGE = 11;
    private LinearLayout root;
    private TextView status, pageInfo;
    private EditText textBox;
    private Button readButton, pauseButton, nextButton, prevButton;
    private SeekBar speedBar;
    private TextToSpeech tts;
    private TessBaseAPI tess;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Uri pdfUri;
    private ParcelFileDescriptor pdfPfd;
    private PdfRenderer pdfRenderer;
    private int pageIndex = 0;
    private boolean speaking = false;
    private File tessDir;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUI();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int ar = tts.setLanguage(new Locale("ar"));
                if (ar == TextToSpeech.LANG_MISSING_DATA || ar == TextToSpeech.LANG_NOT_SUPPORTED)
                    status.setText("الصوت العربي مش متاح أوفلاين على الجهاز. نزّل بيانات صوت عربي من إعدادات تحويل النص إلى كلام.");
            }
        });
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(0xFFF7F5F0);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("اقرألي");
        title.setTextSize(30);
        title.setTextColor(0xFF26352D);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("قارئ PDF والصور بالعربي — المعالجة على جهازك");
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(0xFF555555);
        root.addView(subtitle);

        addButton("📘 افتح ملف PDF", v -> pick(PICK_PDF));
        addButton("🖼️ افتح صورة", v -> pick(PICK_IMAGE));
        pageInfo = new TextView(this);
        pageInfo.setText("اختار ملف PDF أو صورة للبدء");
        pageInfo.setTextSize(14);
        pageInfo.setPadding(0, 12, 0, 8);
        root.addView(pageInfo);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        prevButton = new Button(this); prevButton.setText("السابق");
        nextButton = new Button(this); nextButton.setText("التالي");
        nav.addView(prevButton, new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(nextButton, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(nav);
        prevButton.setOnClickListener(v -> renderPdfPage(Math.max(0, pageIndex - 1)));
        nextButton.setOnClickListener(v -> {
            if (pdfRenderer != null && pageIndex + 1 < pdfRenderer.getPageCount()) renderPdfPage(pageIndex + 1);
        });

        TextView label = new TextView(this);
        label.setText("النص المستخرج (تقدر تعدّله قبل القراءة)");
        label.setTextSize(16);
        label.setPadding(0, 12, 0, 6);
        root.addView(label);

        textBox = new EditText(this);
        textBox.setGravity(Gravity.TOP | Gravity.RIGHT);
        textBox.setTextDirection(View.TEXT_DIRECTION_RTL);
        textBox.setMinLines(8);
        textBox.setTextSize(18);
        textBox.setHint("النص العربي هيظهر هنا...");
        root.addView(textBox, new LinearLayout.LayoutParams(-1, 420));

        addButton("🔎 استخراج النص العربي من الصفحة / الصورة", v -> extractCurrent());
        readButton = new Button(this); readButton.setText("▶ اقرأ النص");
        root.addView(readButton);
        readButton.setOnClickListener(v -> speakText());

        pauseButton = new Button(this); pauseButton.setText("■ إيقاف القراءة");
        root.addView(pauseButton);
        pauseButton.setOnClickListener(v -> { if (tts != null) tts.stop(); speaking = false; });

        TextView speedLabel = new TextView(this);
        speedLabel.setText("سرعة الصوت");
        root.addView(speedLabel);
        speedBar = new SeekBar(this);
        speedBar.setMax(15); speedBar.setProgress(5);
        root.addView(speedBar);

        status = new TextView(this);
        status.setText("ملاحظة: أول مرة تحتاج إنترنت لتنزيل نموذج OCR العربي؛ بعد تنزيله يشتغل OCR بدون نت.");
        status.setTextSize(13);
        status.setTextColor(0xFF555555);
        status.setPadding(0, 12, 0, 8);
        root.addView(status);
    }

    private void addButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        root.addView(b, new LinearLayout.LayoutParams(-1, -2));
        b.setOnClickListener(listener);
    }

    private void pick(int type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type == PICK_PDF ? "application/pdf" : "image/*");
        startActivityForResult(i, type);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        if (requestCode == PICK_PDF) {
            try {
                closePdf();
                pdfUri = uri;
                pdfPfd = getContentResolver().openFileDescriptor(uri, "r");
                pdfRenderer = new PdfRenderer(pdfPfd);
                pageIndex = 0;
                renderPdfPage(0);
                pageInfo.setText("عدد الصفحات: " + pdfRenderer.getPageCount() + " — الصفحة 1");
            } catch (Exception e) { status.setText("مش قادر أفتح ملف PDF: " + e.getMessage()); }
        } else if (requestCode == PICK_IMAGE) {
            pageInfo.setText("تم اختيار صورة");
            extractImage(uri);
        }
    }

    private void renderPdfPage(int index) {
        if (pdfRenderer == null || index < 0 || index >= pdfRenderer.getPageCount()) return;
        pageIndex = index;
        executor.execute(() -> {
            Bitmap bitmap = null;
            try {
                PdfRenderer.Page page = pdfRenderer.openPage(index);
                int width = Math.max(1200, page.getWidth() * 2);
                int height = (int)(width * (page.getHeight() / (float)page.getWidth()));
                bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(0xFFFFFFFF);
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
                final Bitmap b = bitmap;
                runOnUiThread(() -> {
                    pageInfo.setText("الصفحة " + (index + 1) + " من " + pdfRenderer.getPageCount() + " — اضغط استخراج النص");
                    currentBitmap = b;
                });
            } catch (Exception e) { runOnUiThread(() -> status.setText("خطأ في عرض الصفحة: " + e.getMessage())); }
        });
    }

    private Bitmap currentBitmap;

    private void extractCurrent() {
        if (currentBitmap == null) { status.setText("افتح ملف PDF أو صورة الأول."); return; }
        runOcr(currentBitmap);
    }

    private void extractImage(Uri uri) {
        executor.execute(() -> {
            try {
                Bitmap bitmap = android.provider.MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                runOnUiThread(() -> { currentBitmap = bitmap; });
                runOcr(bitmap);
            } catch (Exception e) { runOnUiThread(() -> status.setText("تعذر فتح الصورة: " + e.getMessage())); }
        });
    }

    private void runOcr(Bitmap bitmap) {
        runOnUiThread(() -> status.setText("جاري تجهيز OCR العربي..."));
        executor.execute(() -> {
            try {
                File dataDir = new File(getFilesDir(), "tesseract");
                File tessdata = new File(dataDir, "tessdata");
                if (!tessdata.exists()) tessdata.mkdirs();
                File model = new File(tessdata, "ara.traineddata");
                if (!model.exists()) {
                    runOnUiThread(() -> status.setText("أول مرة: جاري تنزيل نموذج العربية (يحتاج إنترنت مرة واحدة)..."));
                    URL url = new URL("https://github.com/tesseract-ocr/tessdata_fast/raw/main/ara.traineddata");
                    try (InputStream in = url.openStream(); FileOutputStream out = new FileOutputStream(model)) {
                        byte[] buffer = new byte[8192]; int n;
                        while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                    }
                }
                if (tess == null) {
                    tess = new TessBaseAPI();
                    if (!tess.init(dataDir.getAbsolutePath(), "ara")) throw new Exception("فشل تشغيل نموذج OCR العربي");
                }
                tess.setImage(bitmap);
                String result = tess.getUTF8Text();
                final String output = result == null ? "" : result.trim();
                runOnUiThread(() -> {
                    textBox.setText(output);
                    status.setText(output.isEmpty() ? "ملقتش نص واضح. جرّب صورة أوضح." : "تم استخراج النص. راجعه ثم اضغط اقرأ النص.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("حصل خطأ في OCR: " + e.getMessage()));
            }
        });
    }

    private void speakText() {
        if (tts == null) return;
        String text = textBox.getText().toString().trim();
        if (text.isEmpty()) { status.setText("مفيش نص للقراءة."); return; }
        float rate = 0.5f + (speedBar.getProgress() / 10.0f);
        tts.setSpeechRate(rate);
        tts.setLanguage(new Locale("ar"));
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "iqraali_reading");
        speaking = true;
    }

    private void closePdf() {
        try { if (pdfRenderer != null) pdfRenderer.close(); } catch (Exception ignored) {}
        try { if (pdfPfd != null) pdfPfd.close(); } catch (Exception ignored) {}
        pdfRenderer = null; pdfPfd = null;
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (tess != null) tess.end();
        closePdf();
        executor.shutdown();
        super.onDestroy();
    }
}
