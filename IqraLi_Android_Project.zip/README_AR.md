# اقرألي — مشروع Android

تطبيق أندرويد بسيط لفتح PDF أو صورة، واستخراج النص العربي باستخدام Tesseract OCR محليًا، ثم قراءته بصوت Android Text-to-Speech.

## مهم قبل الاستخدام
- تحتاج اتصال إنترنت في أول مرة فقط لتنزيل نموذج OCR العربي `ara.traineddata`. بعد ذلك يعمل استخراج النص بدون إنترنت.
- القراءة الصوتية دون إنترنت تعتمد على تثبيت بيانات صوت عربي أوفلاين في إعدادات تحويل النص إلى كلام على الهاتف.
- جودة OCR تعتمد على وضوح الصورة، واتجاه الصفحة، وجودة الطباعة.
- هذا مشروع مصدر، وليس APK مبنيًا ومختبرًا مسبقًا.

## بناء APK من الموبايل
1. نزّل AndroidIDE من مصدره الرسمي/مستودع GitHub: https://github.com/AndroidIDEOfficial/AndroidIDE
2. افتح AndroidIDE وثبّت أدوات البناء من Terminal بالأمر:
   `idesetup -c`
3. فك ضغط `IqraLi.zip` في مجلد معروف مثل Downloads/IqraLi.
4. في AndroidIDE اختر **Open existing project** وافتح مجلد `IqraLi` الذي يحتوي `settings.gradle`.
5. اتصل بالإنترنت أثناء أول مزامنة Gradle لتنزيل المكتبات. انتظر حتى تنتهي.
6. اختر **Build/Run** أو نفّذ من Terminal داخل مجلد المشروع:
   `gradle assembleDebug`
7. إذا نجح البناء، ستجد الملف هنا:
   `app/build/outputs/apk/debug/app-debug.apk`
8. افتح ملف APK وثبّته. قد تحتاج السماح لـ AndroidIDE أو مدير الملفات بتثبيت تطبيقات غير معروفة.

## ملاحظات
- يحتاج المشروع Android SDK حديثًا وJava 17/إعدادات Gradle متوافقة. إذا ظهر خطأ في إصدار Gradle أو Android Gradle Plugin، راجع توافق نسخة AndroidIDE مع المشروع.
- اختر PDF ثم اضغط «استخراج النص» لكل صفحة، أو افتح صورة ليبدأ استخراجها.
- الكود يستخدم PdfRenderer المدمج في أندرويد، ومكتبة Tess-Two لـ Tesseract.
